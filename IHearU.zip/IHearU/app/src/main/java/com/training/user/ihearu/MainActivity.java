package com.training.user.ihearu;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {


    private TextToSpeech tts;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private static final String PREFS = "prefs";
    private static final String NAME = "name";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        preferences = getSharedPreferences(PREFS,0);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = tts.setLanguage(Locale.US);
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "This Language is not supported");
                    }
                    speak("Choose between blue and red.");
                }else {
                    Log.e("TTS", "Initilization Failed!");
                }
            }
        });
        this.findViewById(R.id.microphoneButton).setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                listen();
            }


        });
    }
    private void speak(String text){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }else {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }
    }
    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
    private void listen(){
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say something");

        try {
            startActivityForResult(i, 100);
        } catch (ActivityNotFoundException a){
            Toast.makeText(MainActivity.this, "Your device doesn't support Speech Recognition", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100){
            if (resultCode == RESULT_OK && null != data) {
                ArrayList<String> res = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String inSpeech = res.get(0);
                recognition(inSpeech);
            }
        }
    }
    private void recognition(String text){
        Log.e("Speech"," " + text);

        //creating an array which contains the words of the answer
        String[] speech = text.split(" ");

        //the last word is our name
        String name = speech[speech.length-1];

        //we got the name, we can put it in local storage and save changes
        editor = preferences.edit();
        editor.putString(NAME,name).apply();

        //RelativeLayout bgElement = (RelativeLayout) findViewById(R.id.rel);
        //bgElement.setBackgroundColor(Color.BLUE);

        //make the app tell you screen color
        //speak("Here is the  "+preferences.getString(NAME,null));
        RelativeLayout bgElement = findViewById(R.id.rel);

        if ("BLUE".equals(preferences.getString(NAME, null)) || preferences.getString(NAME,null).equals ("blue")) {
            bgElement.setBackgroundColor(Color.BLUE);
            speak("Here is the blue screen! ");
        }else{
            final boolean red = "RED".equals(preferences.getString(NAME, null)) || ((preferences.getString(NAME, null)).equals("red"));
            bgElement = findViewById(R.id.rel);
            bgElement.setBackgroundColor(Color.RED);
            speak("Here is the red screen! ");
            }
        }
  }

